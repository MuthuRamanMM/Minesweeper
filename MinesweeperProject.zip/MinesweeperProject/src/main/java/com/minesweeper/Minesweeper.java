package com.minesweeper;

import java.util.*;

public class Minesweeper {
    private static final char MINE = '*';
    private static final char EMPTY = '_';
    private static final char COVERED = '#';

    private int size;
    private int numMines;
    private char[][] minefield;
    private boolean[][] uncovered;
    private boolean[][] mines;
    private boolean gameOver;

    public Minesweeper(int size, int numMines) {
        this.size = size;
        this.numMines = numMines;
        minefield = new char[size][size];
        uncovered = new boolean[size][size];
        mines = new boolean[size][size];
        gameOver = false;

        for (int i = 0; i < size; i++) {
            Arrays.fill(minefield[i], COVERED);
        }

        placeMines();
        calculateHints();
    }

    private void placeMines() {
        Random rand = new Random();
        int placedMines = 0;
        while (placedMines < numMines) {
            int row = rand.nextInt(size);
            int col = rand.nextInt(size);
            if (!mines[row][col]) {
                mines[row][col] = true;
                placedMines++;
            }
        }
    }

    private void calculateHints() {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (mines[i][j]) {
                    minefield[i][j] = MINE;
                } else {
                    int mineCount = countAdjacentMines(i, j);
                    minefield[i][j] = (char) ('0' + mineCount);
                }
            }
        }
    }

    private int countAdjacentMines(int row, int col) {
        int count = 0;
        for (int i = row - 1; i <= row + 1; i++) {
            for (int j = col - 1; j <= col + 1; j++) {
                if (i >= 0 && i < size && j >= 0 && j < size && mines[i][j]) {
                    count++;
                }
            }
        }
        return count;
    }

    public void play() {
        Scanner scanner = new Scanner(System.in);
        while (!gameOver) {
            displayMinefield();
            System.out.print("Select a square to reveal (e.g. A1): ");
            String input = scanner.next();
            int row = input.charAt(0) - 'A';
            int col = input.charAt(1) - '1';

            if (row < 0 || row >= size || col < 0 || col >= size) {
                System.out.println("Invalid input. Try again.");
                continue;
            }

            if (mines[row][col]) {
                System.out.println("You hit a mine! Game over.");
                gameOver = true;
                revealAllMines();
            } else {
                uncover(row, col);
                if (isGameWon()) {
                    displayMinefield();
                    System.out.println("Congratulations! You've cleared the minefield.");
                    gameOver = true;
                }
            }
        }
        scanner.close();
    }

    private void uncover(int row, int col) {
        if (row < 0 || row >= size || col < 0 || col >= size || uncovered[row][col]) {
            return;
        }

        uncovered[row][col] = true;
        if (minefield[row][col] == '0') {
            for (int i = row - 1; i <= row + 1; i++) {
                for (int j = col - 1; j <= col + 1; j++) {
                    uncover(i, j);
                }
            }
        }
    }

    private boolean isGameWon() {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (!mines[i][j] && !uncovered[i][j]) {
                    return false;
                }
            }
        }
        return true;
    }

    private void displayMinefield() {
        System.out.print("  ");
        for (int i = 1; i <= size; i++) {
            System.out.print(i + " ");
        }
        System.out.println();

        for (int i = 0; i < size; i++) {
            System.out.print((char) ('A' + i) + " ");
            for (int j = 0; j < size; j++) {
                if (uncovered[i][j]) {
                    System.out.print(minefield[i][j] + " ");
                } else {
                    System.out.print(COVERED + " ");
                }
            }
            System.out.println();
        }
    }

    private void revealAllMines() {
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (mines[i][j]) {
                    uncovered[i][j] = true;
                }
            }
        }
        displayMinefield();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to Minesweeper!");
        System.out.print("Enter the size of the grid (e.g. 4 for a 4x4 grid): ");
        int size = scanner.nextInt();

        int maxMines = (int) (0.35 * size * size);
        System.out.print("Enter the number of mines to place on the grid (maximum is " + maxMines + "): ");
        int numMines = scanner.nextInt();

        while (numMines > maxMines) {
            System.out.println("Number of mines exceeds the maximum limit. Try again.");
            numMines = scanner.nextInt();
        }

        Minesweeper game = new Minesweeper(size, numMines);
        game.play();
    }
}
