
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MinesweeperTest {

    private Minesweeper game;

    @BeforeEach
    public void setUp() {
        game = new Minesweeper(4, 2);
    }

    @Test
    public void testMinePlacement() {
        int mineCount = 0;
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                if (game.isMine(i, j)) {
                    mineCount++;
                }
            }
        }
        assertEquals(2, mineCount, "Number of mines placed should be equal to 2");
    }

    @Test
    public void testAdjacentMineCount() {

        game.placeMine(0, 0);
        game.placeMine(1, 1);
        assertEquals('1', game.getMinefield()[0][1], "There should be 1 adjacent mine.");
        assertEquals('2', game.getMinefield()[1][0], "There should be 2 adjacent mines.");
    }

    @Test
    public void testUncoverNonMine() {
        game.placeMine(0, 0);
        game.uncover(1, 1);
        assertTrue(game.isUncovered(1, 1), "Square should be uncovered.");
    }

    @Test
    public void testUncoverMine() {
        game.placeMine(0, 0);
        game.uncover(0, 0);
        assertTrue(game.isGameOver(), "Game should be over after uncovering a mine.");
    }

    @Test
    public void testUncoverAdjacentZero() {
        game.placeMine(0, 0);
        game.placeMine(0, 1);
        game.uncover(3, 3);
        assertTrue(game.isUncovered(3, 3), "Square should be uncovered.");
        assertTrue(game.isUncovered(2, 2), "Adjacent zero square should be uncovered.");
    }

    @Test
    public void testWinCondition() {

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                if (!game.isMine(i, j)) {
                    game.uncover(i, j);
                }
            }
        }
        assertTrue(game.isGameWon(), "Game should be won after all non-mine squares are uncovered.");
    }
}

